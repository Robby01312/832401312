# 前后端分离计算器系统 —— 后端

## 一、项目简介

本项目是前后端分离架构计算器系统的后端，使用 **C++17** 编写，负责：

- 表达式的语法校验与安全解析（不使用 `eval`，手写调度场算法）
- 数值计算（四则运算、优先级、括号、小数、一元正负号）
- 异常处理（非法表达式、除零、非法 JSON）
- 计算历史在 SQLite 数据库中的持久化、查询与删除
- 对外提供 REST API（HTTP + JSON）

## 二、技术栈

| 模块 | 技术 |
|:---|:---|
| Web 框架 | [cpp-httplib](https://github.com/yhirose/cpp-httplib)（单头文件） |
| JSON 解析 | [nlohmann/json](https://github.com/nlohmann/json)（单头文件） |
| 数据库 | SQLite（amalgamation 源码直接编译） |
| 构建 | CMake / Docker |
| 语言标准 | C++17 |

## 三、目录结构

```
calculator_backend/
├── CMakeLists.txt
├── Dockerfile
├── third_party/            # 第三方头文件
│   ├── httplib.h
│   └── nlohmann/json.hpp
├── sqlite/                 # SQLite amalgamation 源码
│   ├── sqlite3.c
│   ├── sqlite3.h
│   └── sqlite3ext.h
└── src/
    ├── main.cpp            # HTTP 路由（API 层）
    ├── calculator.h/.cpp   # 核心计算（调度场算法）
    └── database.h/.cpp     # 数据库访问层
```

## 四、本地构建与运行

### 方式一：CMake

```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release -j
./build/calculator_server
```

> Windows（MinGW）下会自动定义 `_WIN32_WINNT=0x0A00` 并链接 `ws2_32`。

### 方式二：Docker

```bash
docker build -t calculator_server .
docker run -p 8080:8080 calculator_server
```

服务默认监听 `http://0.0.0.0:8080`，可通过环境变量 `PORT` 修改端口。

## 五、API 接口

| 方法 | 路径 | 说明 |
|:---|:---|:---|
| POST | `/api/calculate` | 提交表达式，后端计算并保存历史 |
| GET  | `/api/history` | 获取全部计算历史（按 id 倒序） |
| DELETE | `/api/history/{id}` | 删除指定 id 的历史记录 |

### 计算接口示例

请求：

```json
{ "expression": "(1+2)*3" }
```

成功响应：

```json
{
  "success": true,
  "data": { "id": 1, "expression": "(1+2)*3", "result": "9" }
}
```

错误响应（如除零）：

```json
{ "success": false, "message": "计算错误: 除数不能为零" }
```

## 六、数据库

- 数据库文件：`calculator.db`（程序启动自动创建）
- 表名：`calculation_history`

| 字段 | 类型 | 说明 |
|:---|:---|:---|
| id | INTEGER PRIMARY KEY AUTOINCREMENT | 主键 |
| expression | TEXT NOT NULL | 原始表达式 |
| result | TEXT NOT NULL | 计算结果 |
| created_at | DATETIME NOT NULL | 创建时间 |
