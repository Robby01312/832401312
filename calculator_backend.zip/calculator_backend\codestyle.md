# 后端代码规范

本项目后端遵循 **Google C++ Style Guide**（https://google.github.io/styleguide/cppguide.html ）。

## 核心规范

1. **缩进**：统一使用 2 个空格缩进，不使用 Tab。
2. **命名**：
   - 类名使用大驼峰（PascalCase），如 `Calculator`、`HistoryRecord`；
   - 函数名使用蛇形命名（snake_case），如 `add_history`、`get_all_history`；
   - 变量名使用蛇形命名，类的成员变量以下划线结尾，如 `db_path_`；
   - 常量使用 `k` 开头的大驼峰，如 `kUnaryPrecedence`。
3. **头文件**：一律使用 `#ifndef` 头文件保护（include guard），命名与文件路径对应。
4. **头文件包含顺序**：对应头文件 → C 标准库 → C++ 标准库 → 第三方库 → 本项目头文件，组间空行。
5. **异常**：通过自定义异常类（`InvalidExpressionError`、`DivisionByZeroError`）表达错误，不使用错误码返回，捕获时使用 `const &`。
6. **注释**：核心函数必须添加注释，说明功能、参数与返回值；注释解释“为什么”，而非“做什么”。
7. **内存管理**：第三方 C 接口（sqlite3）遵循其 open/close、prepare/finalize 配对规则，使用 RAII 封装。
