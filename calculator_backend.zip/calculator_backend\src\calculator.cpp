#include "calculator.h"

#include <cctype>
#include <stack>
#include <string>
#include <vector>

namespace {

enum class TokenType { Number, Op, UnaryOp, LParen, RParen };

struct Token {
    TokenType type;
    double value = 0.0;
    char op = 0;
};

// 一元运算符优先级（高于乘除），右结合
constexpr int UNARY_PRECEDENCE = 3;

// 第一步：分词
std::vector<Token> tokenize(const std::string& expr) {
    std::vector<Token> tokens;
    const size_t n = expr.size();
    size_t i = 0;

    while (i < n) {
        char c = expr[i];
        if (std::isspace(static_cast<unsigned char>(c))) {
            ++i;
            continue;
        }

        // 数字（含小数）
        if (std::isdigit(static_cast<unsigned char>(c)) || c == '.') {
            size_t j = i;
            int dotCount = 0;
            while (j < n && (std::isdigit(static_cast<unsigned char>(expr[j])) || expr[j] == '.')) {
                if (expr[j] == '.') {
                    ++dotCount;
                }
                ++j;
            }
            std::string numStr = expr.substr(i, j - i);
            if (dotCount > 1 || numStr == ".") {
                throw InvalidExpressionError("非法数字: " + numStr);
            }
            tokens.push_back({TokenType::Number, std::stod(numStr), 0});
            i = j;
            continue;
        }

        if (c == '(') {
            tokens.push_back({TokenType::LParen, 0.0, c});
            ++i;
            continue;
        }

        if (c == ')') {
            tokens.push_back({TokenType::RParen, 0.0, c});
            ++i;
            continue;
        }

        if (c == '+' || c == '-' || c == '*' || c == '/') {
            // 一元正负号：前面没有数字或右括号时，识别为高优先级一元运算符
            if (c == '-' || c == '+') {
                bool prevIsValue = false;
                if (!tokens.empty()) {
                    TokenType prev = tokens.back().type;
                    prevIsValue = (prev == TokenType::Number || prev == TokenType::RParen);
                }
                if (!prevIsValue) {
                    tokens.push_back({TokenType::UnaryOp, 0.0, c});
                    ++i;
                    continue;
                }
            }
            tokens.push_back({TokenType::Op, 0.0, c});
            ++i;
            continue;
        }

        throw InvalidExpressionError(std::string("非法字符: ") + c);
    }

    return tokens;
}

int precedence(char op) {
    if (op == '*' || op == '/') {
        return 2;
    }
    if (op == '+' || op == '-') {
        return 1;
    }
    return 0;
}

// 第二步：调度场算法，中缀 -> 后缀
std::vector<Token> toPostfix(const std::vector<Token>& tokens) {
    std::vector<Token> output;
    std::stack<Token> ops;

    for (const Token& t : tokens) {
        switch (t.type) {
            case TokenType::Number:
                output.push_back(t);
                break;

            case TokenType::LParen:
                ops.push(t);
                break;

            case TokenType::RParen: {
                bool found = false;
                while (!ops.empty()) {
                    Token top = ops.top();
                    ops.pop();
                    if (top.type == TokenType::LParen) {
                        found = true;
                        break;
                    }
                    output.push_back(top);
                }
                if (!found) {
                    throw InvalidExpressionError("括号不匹配");
                }
                break;
            }

            case TokenType::UnaryOp:
                // 一元运算符右结合：仅当栈顶是更高优先级的运算符时才弹出
                while (!ops.empty() && ops.top().type != TokenType::LParen) {
                    const Token& top = ops.top();
                    int topPrec = (top.type == TokenType::UnaryOp)
                                      ? UNARY_PRECEDENCE
                                      : precedence(top.op);
                    if (topPrec > UNARY_PRECEDENCE) {
                        output.push_back(top);
                        ops.pop();
                    } else {
                        break;
                    }
                }
                ops.push(t);
                break;

            case TokenType::Op:
                // 二元运算符左结合：栈顶优先级 >= 当前即弹出
                while (!ops.empty() && ops.top().type != TokenType::LParen) {
                    const Token& top = ops.top();
                    int topPrec = (top.type == TokenType::UnaryOp)
                                      ? UNARY_PRECEDENCE
                                      : precedence(top.op);
                    if (topPrec >= precedence(t.op)) {
                        output.push_back(top);
                        ops.pop();
                    } else {
                        break;
                    }
                }
                ops.push(t);
                break;
        }
    }

    while (!ops.empty()) {
        Token top = ops.top();
        ops.pop();
        if (top.type == TokenType::LParen) {
            throw InvalidExpressionError("括号不匹配");
        }
        output.push_back(top);
    }

    return output;
}

// 第三步：后缀表达式求值
double evalPostfix(const std::vector<Token>& postfix) {
    std::stack<double> st;

    for (const Token& t : postfix) {
        if (t.type == TokenType::Number) {
            st.push(t.value);
            continue;
        }

        if (t.type == TokenType::UnaryOp) {
            if (st.empty()) {
                throw InvalidExpressionError("表达式语法错误");
            }
            double v = st.top();
            st.pop();
            st.push(t.op == '-' ? -v : v);
            continue;
        }

        if (st.size() < 2) {
            throw InvalidExpressionError("表达式语法错误");
        }
        double b = st.top();
        st.pop();
        double a = st.top();
        st.pop();

        switch (t.op) {
            case '+':
                st.push(a + b);
                break;
            case '-':
                st.push(a - b);
                break;
            case '*':
                st.push(a * b);
                break;
            case '/':
                if (b == 0.0) {
                    throw DivisionByZeroError("除数不能为零");
                }
                st.push(a / b);
                break;
            default:
                break;
        }
    }

    if (st.size() != 1) {
        throw InvalidExpressionError("表达式语法错误");
    }
    return st.top();
}

}  // namespace

double Calculator::calculate(const std::string& expression) {
    size_t first = expression.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) {
        throw InvalidExpressionError("表达式不能为空");
    }

    std::vector<Token> tokens = tokenize(expression);
    if (tokens.empty()) {
        throw InvalidExpressionError("表达式不能为空");
    }

    std::vector<Token> postfix = toPostfix(tokens);
    return evalPostfix(postfix);
}
