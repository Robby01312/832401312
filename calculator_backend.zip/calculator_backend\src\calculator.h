#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <stdexcept>
#include <string>

// 计算异常基类
class CalculatorError : public std::runtime_error {
public:
    explicit CalculatorError(const std::string& msg) : std::runtime_error(msg) {}
};

// 非法表达式异常
class InvalidExpressionError : public CalculatorError {
public:
    explicit InvalidExpressionError(const std::string& msg) : CalculatorError(msg) {}
};

// 除零异常
class DivisionByZeroError : public CalculatorError {
public:
    explicit DivisionByZeroError(const std::string& msg) : CalculatorError(msg) {}
};

class Calculator {
public:
    // 对外计算入口
    double calculate(const std::string& expression);
};

#endif // CALCULATOR_H
