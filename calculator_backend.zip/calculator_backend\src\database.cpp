#include "database.h"

#include <ctime>
#include <stdexcept>

#include "sqlite3.h"

namespace {

std::string now_string() {
    std::time_t t = std::time(nullptr);
    std::tm tm{};
#if defined(_WIN32)
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &tm);
    return std::string(buf);
}

}  // namespace

Database::Database(const std::string& db_path) : db_path_(db_path), db_(nullptr) {
    if (sqlite3_open(db_path.c_str(), &db_) != SQLITE_OK) {
        std::string err = db_ ? sqlite3_errmsg(db_) : "unknown error";
        if (db_) {
            sqlite3_close(db_);
            db_ = nullptr;
        }
        throw std::runtime_error("无法打开数据库: " + err);
    }
}

Database::~Database() {
    if (db_) {
        sqlite3_close(db_);
        db_ = nullptr;
    }
}

void Database::init() {
    const char* sql = R"(
        CREATE TABLE IF NOT EXISTS calculation_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            expression TEXT NOT NULL,
            result TEXT NOT NULL,
            created_at DATETIME NOT NULL
        );
    )";
    char* err_msg = nullptr;
    if (sqlite3_exec(db_, sql, nullptr, nullptr, &err_msg) != SQLITE_OK) {
        std::string err = err_msg;
        sqlite3_free(err_msg);
        throw std::runtime_error("建表失败: " + err);
    }
}

int Database::add_history(const std::string& expression, const std::string& result) {
    const char* sql =
        "INSERT INTO calculation_history (expression, result, created_at) "
        "VALUES (?, ?, ?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        throw std::runtime_error(std::string("SQL准备失败: ") + sqlite3_errmsg(db_));
    }

    std::string created_at = now_string();
    sqlite3_bind_text(stmt, 1, expression.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, result.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, created_at.c_str(), -1, SQLITE_TRANSIENT);

    if (sqlite3_step(stmt) != SQLITE_DONE) {
        sqlite3_finalize(stmt);
        throw std::runtime_error(std::string("插入失败: ") + sqlite3_errmsg(db_));
    }
    sqlite3_finalize(stmt);

    return static_cast<int>(sqlite3_last_insert_rowid(db_));
}

std::vector<HistoryRecord> Database::get_all_history() {
    std::vector<HistoryRecord> records;
    const char* sql =
        "SELECT id, expression, result, created_at "
        "FROM calculation_history ORDER BY id DESC;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        throw std::runtime_error(std::string("SQL准备失败: ") + sqlite3_errmsg(db_));
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        HistoryRecord r;
        r.id = sqlite3_column_int(stmt, 0);
        const unsigned char* expr = sqlite3_column_text(stmt, 1);
        const unsigned char* res = sqlite3_column_text(stmt, 2);
        const unsigned char* created = sqlite3_column_text(stmt, 3);
        r.expression = expr ? reinterpret_cast<const char*>(expr) : "";
        r.result = res ? reinterpret_cast<const char*>(res) : "";
        r.created_at = created ? reinterpret_cast<const char*>(created) : "";
        records.push_back(r);
    }
    sqlite3_finalize(stmt);
    return records;
}

bool Database::delete_history(int id) {
    const char* sql = "DELETE FROM calculation_history WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        throw std::runtime_error(std::string("SQL准备失败: ") + sqlite3_errmsg(db_));
    }
    sqlite3_bind_int(stmt, 1, id);
    sqlite3_step(stmt);
    sqlite3_finalize(stmt);
    return sqlite3_changes(db_) > 0;
}
