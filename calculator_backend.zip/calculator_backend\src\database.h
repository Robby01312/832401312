#ifndef DATABASE_H
#define DATABASE_H

#include <string>
#include <vector>

// 前向声明，避免头文件暴露 sqlite3.h
struct sqlite3;

// 一条计算历史记录
struct HistoryRecord {
    int id;
    std::string expression;
    std::string result;
    std::string created_at;
};

class Database {
public:
    explicit Database(const std::string& db_path);
    ~Database();

    // 初始化（建表）
    void init();

    // 新增一条历史，返回自增主键 id
    int add_history(const std::string& expression, const std::string& result);

    // 查询全部历史（按 id 倒序）
    std::vector<HistoryRecord> get_all_history();

    // 删除指定 id 的记录，返回是否删除成功
    bool delete_history(int id);

private:
    std::string db_path_;
    sqlite3* db_;
};

#endif  // DATABASE_H
