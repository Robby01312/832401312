#include <cstdlib>
#include <exception>
#include <iostream>
#include <sstream>
#include <string>

#include "calculator.h"
#include "database.h"
#include "httplib.h"
#include "nlohmann/json.hpp"

using json = nlohmann::json;

namespace {

// 格式化结果：整数去掉小数部分
std::string format_result(double v) {
    if (v == static_cast<long long>(v)) {
        return std::to_string(static_cast<long long>(v));
    }
    std::ostringstream oss;
    oss << v;
    return oss.str();
}

json success_json(const json& data) {
    return json{{"success", true}, {"data", data}};
}

json error_json(const std::string& message) {
    return json{{"success", false}, {"message", message}};
}

}  // namespace

int main() {
    const std::string db_path = "calculator.db";
    Database db(db_path);
    db.init();

    httplib::Server svr;

    // CORS：允许前端跨域访问
    svr.set_default_headers({{"Access-Control-Allow-Origin", "*"},
                             {"Access-Control-Allow-Methods",
                              "GET, POST, DELETE, OPTIONS"},
                             {"Access-Control-Allow-Headers", "Content-Type"}});
    svr.Options(".*",
                [](const httplib::Request&, httplib::Response& res) {
                    res.status = 204;
                });

    // 计算接口
    svr.Post("/api/calculate",
             [&](const httplib::Request& req, httplib::Response& res) {
                 json body = json::parse(req.body, nullptr, false);
                 if (body.is_discarded() || !body.contains("expression") ||
                     !body["expression"].is_string()) {
                     res.status = 400;
                     res.set_content(
                         error_json("缺少expression字段或请求体不是合法JSON").dump(),
                         "application/json");
                     return;
                 }

                 std::string expression = body["expression"].get<std::string>();

                 try {
                     Calculator calc;
                     double result = calc.calculate(expression);
                     std::string result_str = format_result(result);
                     int id = db.add_history(expression, result_str);

                     json data = {{"id", id},
                                  {"expression", expression},
                                  {"result", result_str}};
                     res.set_content(success_json(data).dump(),
                                     "application/json");
                 } catch (const InvalidExpressionError& e) {
                     res.status = 400;
                     res.set_content(
                         error_json(std::string("非法表达式: ") + e.what()).dump(),
                         "application/json");
                 } catch (const DivisionByZeroError& e) {
                     res.status = 400;
                     res.set_content(
                         error_json(std::string("计算错误: ") + e.what()).dump(),
                         "application/json");
                 } catch (const std::exception& e) {
                     res.status = 500;
                     res.set_content(
                         error_json(std::string("服务器错误: ") + e.what()).dump(),
                         "application/json");
                 }
             });

    // 历史查询接口
    svr.Get("/api/history",
            [&](const httplib::Request&, httplib::Response& res) {
                try {
                    auto records = db.get_all_history();
                    json arr = json::array();
                    for (const auto& r : records) {
                        arr.push_back({{"id", r.id},
                                       {"expression", r.expression},
                                       {"result", r.result},
                                       {"created_at", r.created_at}});
                    }
                    res.set_content(success_json(arr).dump(),
                                    "application/json");
                } catch (const std::exception& e) {
                    res.status = 500;
                    res.set_content(
                        error_json(std::string("查询失败: ") + e.what()).dump(),
                        "application/json");
                }
            });

    // 删除历史接口
    svr.Delete(R"(/api/history/(\d+))",
               [&](const httplib::Request& req, httplib::Response& res) {
                   try {
                       int id = std::stoi(req.matches[1].str());
                       bool ok = db.delete_history(id);
                       if (ok) {
                           res.set_content(
                               success_json({{"deleted", id}}).dump(),
                               "application/json");
                       } else {
                           res.status = 404;
                           res.set_content(error_json("记录不存在").dump(),
                                           "application/json");
                       }
                   } catch (const std::exception& e) {
                       res.status = 400;
                       res.set_content(
                           error_json(std::string("删除失败: ") + e.what()).dump(),
                           "application/json");
                   }
               });

    // 端口：本地默认 8080；Render 等平台通过 PORT 环境变量注入
    int port = 8080;
    if (const char* port_env = std::getenv("PORT")) {
        port = std::stoi(port_env);
    }

    std::cout << "C++ Calculator backend listening on http://0.0.0.0:" << port << "\n";
    svr.listen("0.0.0.0", port);
    return 0;
}
