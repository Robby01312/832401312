# 前后端分离计算器系统 —— 前端

## 一、项目简介

本项目是前后端分离架构计算器系统的前端，使用原生 **HTML + CSS + JavaScript** 实现，不包含任何核心计算逻辑，仅负责：

- 按钮交互与表达式拼接
- 表达式与结果的展示
- 计算历史的展示与删除
- 通过 HTTP API 调用后端

## 二、技术栈

- HTML5
- CSS3
- 原生 JavaScript（ES6+，使用 fetch / async-await）

## 三、运行方式

1. 先启动后端服务（默认监听 8080 端口）。
2. 直接双击 `index.html`，或使用 VS Code 的 Live Server 插件打开。
3. 若后端地址变化，修改 `app.js` 开头的 `API_BASE`：

```javascript
const API_BASE = 'http://localhost:8080/api';
```

## 四、符号约定

- 界面显示友好符号：`×`、`÷`、`−`；
- 发送给后端时使用程序符号：`*`、`/`、`-`。

## 五、调用的接口

| 方法 | 路径 | 说明 |
|:---|:---|:---|
| POST | `/api/calculate` | 提交表达式 |
| GET | `/api/history` | 获取历史 |
| DELETE | `/api/history/{id}` | 删除一条历史 |
