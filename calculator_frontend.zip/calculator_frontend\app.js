// 后端 API 地址：本地测试用 http://localhost:8080/api；部署后替换为线上地址
const API_BASE = 'http://localhost:8080/api';

let currentExpression = '';

const expressionEl = document.getElementById('expression');
const resultEl = document.getElementById('result');
const historyListEl = document.getElementById('history-list');

document.addEventListener('DOMContentLoaded', () => {
    bindButtons();
    loadHistory();
});

// 绑定所有按钮
function bindButtons() {
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const action = btn.dataset.action;
            const value = btn.dataset.value;

            if (action === 'clear') {
                currentExpression = '';
                updateDisplay();
            } else if (action === 'backspace') {
                currentExpression = currentExpression.slice(0, -1);
                updateDisplay();
            } else if (action === 'calculate') {
                doCalculate();
            } else if (value) {
                currentExpression += value;
                updateDisplay();
            }
        });
    });
}

// 界面显示友好符号 × ÷，内部表达式仍用 * /
function updateDisplay() {
    const displayExpr = currentExpression
        .replace(/\*/g, '×')
        .replace(/\//g, '÷');
    expressionEl.textContent = displayExpr;
}

// 调用后端计算接口（前端不做任何计算）
async function doCalculate() {
    if (!currentExpression.trim()) {
        return;
    }
    try {
        const res = await fetch(`${API_BASE}/calculate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ expression: currentExpression })
        });
        const data = await res.json();

        if (data.success) {
            resultEl.textContent = data.data.result;
            loadHistory();
        } else {
            resultEl.textContent = '错误';
            alert(data.message);
        }
    } catch (err) {
        resultEl.textContent = '连接失败';
        alert('无法连接后端服务，请先启动后端程序');
    }
}

// 加载历史记录
async function loadHistory() {
    try {
        const res = await fetch(`${API_BASE}/history`);
        const data = await res.json();
        if (data.success) {
            renderHistory(data.data);
        }
    } catch (err) {
        historyListEl.innerHTML = '<p>加载历史失败</p>';
    }
}

// 渲染历史列表
function renderHistory(list) {
    if (!list.length) {
        historyListEl.innerHTML = '<p>暂无历史记录</p>';
        return;
    }
    historyListEl.innerHTML = list.map(item => `
        <div class="history-item">
            <div>
                <div class="expr">${item.expression.replace(/\*/g, '×').replace(/\//g, '÷')}</div>
                <div class="res">= ${item.result}</div>
            </div>
            <button class="del-btn" onclick="deleteHistory(${item.id})">删除</button>
        </div>
    `).join('');
}

// 删除单条历史
async function deleteHistory(id) {
    if (!confirm('确定删除这条记录？')) {
        return;
    }
    try {
        const res = await fetch(`${API_BASE}/history/${id}`, { method: 'DELETE' });
        const data = await res.json();
        if (data.success) {
            loadHistory();
        } else {
            alert('删除失败');
        }
    } catch (err) {
        alert('请求失败');
    }
}
