# 前端代码规范

本项目前端遵循 **Airbnb JavaScript Style Guide**（https://github.com/airbnb/javascript ）。

## 核心规范

1. **缩进**：统一使用 2 个空格缩进，不使用 Tab。
2. **命名**：变量与函数使用小驼峰命名（camelCase），如 `currentExpression`、`loadHistory`；常量使用全大写蛇形命名，如 `API_BASE`。
3. **字符串**：优先使用单引号。
4. **语句结尾**：统一使用分号。
5. **异步**：统一使用 `async / await`，并通过 `try / catch` 处理异常。
6. **DOM 操作**：统一通过 `id` 获取元素，避免全局变量污染；事件通过 `data-*` 属性传递参数。
7. **注释**：关键函数必须添加注释，说明功能与参数。
